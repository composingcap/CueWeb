// This file has invalid javascript syntax
const MaxMSP = require('max-api');

def python_method(arg):
	print "What language do you think you're in?"
