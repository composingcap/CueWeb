module.exports = {

	env: {
		es6: true,
		node: true,
		browser: true
	},
	globals: {
		"$": true
	}
};
