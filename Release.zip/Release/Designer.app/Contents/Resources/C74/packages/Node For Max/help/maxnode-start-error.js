// This file has valid javascript syntax, but will throw an error when you try to run it
const Max = require("max-api");
const nonsense = 4 / y;

Max.post(nonsense);
