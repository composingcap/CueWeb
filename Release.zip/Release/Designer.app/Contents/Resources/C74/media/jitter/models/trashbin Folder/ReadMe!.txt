Garbage can modelled with Amapi

5591 polygons

3 objects

One textures can be used as a diffuse color for this object:

- rustbin.jpg

Use it in conjuction with a slightly reflective metal texture

There are mapping coordinates on every element of this object



---------------------------------



Poubelle mod�lis�e avec Amapi

5591 polygones 

3 objets 

La texture rustbin.jpg peut �tre utilis�e comme couleur diffuse pour cet objet.

Il y a des coordonn�es de mapping sur chacun des �l�ments.





=================================

From The Virtual lands Meshbank



http://o.ffrench.free.fr/meshbank

=================================