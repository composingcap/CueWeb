Starfish modelled with Amapi	
1 object
3776 polygons
No texture (a procedural noise will be the more appropriate)

---------------------------------

Etoile de mer mod�lis�e avec Amapi
1 objet
3776 polygones
Pas de texture (utiliser un bruit proc�dural)

=================================
From The Virtual lands Meshbank

http://o.ffrench.free.fr/meshbank
=================================